﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quiz1
{
   public class Moto : Vehiculo
    {
        public Moto()
        {

        }
        private String _Cilindraje;
        private String _Marca;


        public String Cilindraje
        {
            get{ return _Cilindraje; }
            set { _Cilindraje = value; }
        }

        

        public String Marca
        {
            get { return _Marca; }
            set { _Marca = value; }
        }
    }
}
