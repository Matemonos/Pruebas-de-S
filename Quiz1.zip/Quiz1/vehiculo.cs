﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quiz1
{
    public class Vehiculo
    {
        public Vehiculo()
        {

        }
        private String _Modelo;
        private String _Matricula;
        private String _Potencia;

        public String Modelo
        {
            get { return _Modelo; }
            set { _Modelo = value; }
        }

        public String Matricula
        {
            get { return _Matricula; }
            set { _Matricula = value; }
        }

        public String Potencia
        {
            get { return _Potencia; }
            set { _Potencia = value; }
        }

    }
}
