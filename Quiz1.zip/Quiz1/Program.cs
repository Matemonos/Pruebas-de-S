﻿using System;
using System.Collections.Generic;

namespace Quiz1
{
    class Program
    {
        static void Main(string[] args)
        {

            Moto m = null;

            List<Moto> listaM = new List<Moto>();

            for (int i = 0; i < 5; i++)
            {
                m = new Moto();
                m.Modelo = "2019";
                m.Matricula = "ASW-214";
                m.Potencia = "10 caballos de fuerza";
                m.Cilindraje = "150cc";
                m.Marca = "Yamaha";
                listaM.Add(m);
            }

            foreach(Moto x in listaM)
            {
                Console.WriteLine("Moto Modelo: " + m.Modelo + "\n" +
                    "matricula: " +m.Matricula +"\n" +
                    "potencia: " + m.Potencia + "\n" +
                    "cilindraje: " + m.Cilindraje + "\n" +
                    "Marca: " + m.Marca +"\n");
            }

        }
    }
}
